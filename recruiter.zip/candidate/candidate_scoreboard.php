<div class="row">
    <div class="col-12 col-lg-8 mx-auto">
        <div class="cards-wrapper">
            <div class="cards cl-purple">
                <div class="icon">
                    <i class="fa fa-check"></i>
                </div>
                <div class="card-details">
                    <div class="c-title">Jobs Posted</div>
                    <div class="c-no">15</div>
                </div>
            </div>
            <div class="cards cl-green">
                <div class="icon">
                    <i class="fa fa-user"></i>
                </div>
                <div class="card-details">
                    <div class="c-title">Active Jobs</div>
                    <div class="c-no">10</div>
                </div>
            </div>
            <div class="cards cl-blue">
                <div class="icon">
                    <i class="fa fa-download"></i>
                </div>
                <div class="card-details">
                    <div class="c-title">Applications</div>
                    <div class="c-no">12</div>
                </div>
            </div>
        </div>
    </div>
</div>